#!/bin/bash

start () {
    # ------------------------------ Configuraçoes Gerais ------------------------------ #

    iptables -F -t nat  
    iptables -F -t filter
    iptables -F -t mangle

    iptables -P INPUT 	ACCEPT
    iptables -P OUTPUT 	ACCEPT
    iptables -P FORWARD ACCEPT

    iptables -A INPUT -i lo -j ACCEPT
    iptables -A OUTPUT -o lo -j ACCEPT
   
    # ------------------------------ Rede Local <-> Internet ------------------------------ #

    ## ------------------------------ INICIO - Habilitando os LOG's ------------------------------ ##
    # Habilitando LOGs para as requisicoes DNS
    iptables -A FORWARD -p udp -s 192.168.1.0/24 --dport 53 -j LOG --log-prefix " [ Request DNS: ] "
    iptables -A FORWARD -p udp -d 192.168.1.0/24 --sport 53 -j LOG --log-prefix " [ Reply DNS: ] "
    
    # Habilitando LOGs para requisicoes HTTPS
    iptables -A FORWARD -p tcp --dport 443 -o eth1 -s 192.168.1.0/24 -j LOG --log-prefix " [ Request HTTPS: ] "
    iptables -A FORWARD -p tcp --sport 443 -i eth1 -d 192.168.1.0/24 -j LOG --log-prefix " [ Reply HTTPS: ] "
    
    # Habilita o Log do Acesso via SSH
    iptables -A INPUT -p tcp --dport 22 -j LOG --log-prefix " [ Resquest SSH: ] "
    iptables -A OUTPUT -p tcp --sport 22 -j LOG --log-prefix " [ Replay SSH: ] "
    
    ## ------------------------------ FIM - Habilitando os LOG's ------------------------------ ##

    # Roteando Internet com SNAT
    iptables -A POSTROUTING -t nat -s 192.168.1.0/24 -o eth1 -j SNAT --to 192.168.100.133

    # Liberando requisicoes DNS
    iptables -A FORWARD -p udp --dport 53 -s 192.168.1.0/24 -d 8.8.8.8,8.8.4.4 -j ACCEPT
    iptables -A FORWARD -p udp --sport 53 -d 192.168.1.0/24 -s 8.8.8.8,8.8.4.4 --dport 1024:65535 -j ACCEPT
    
    # Habilitando ICMP
    iptables -A FORWARD -p icmp --icmp-type echo-request -s 192.168.1.0/24 -m state --state NEW -j ACCEPT

    # Liberando requisicoes HTTP e HTTPS 
    iptables -A FORWARD -p tcp -m multiport --dports 80,443 -s 192.168.1.0/24 -m state --state NEW -j ACCEPT

    # Priorizacao Maxima (TOS=10) nas requisicoes HTTPS
    iptables -A FORWARD -t mangle -p tcp --dport 443 -s 192.168.1.0/24 -j TOS --set-tos 16
    iptables -A FORWARD -t mangle -p tcp --sport 443 -d 192.168.1.0/24 -j TOS --set-tos 16

    # Alterado o TTL
    iptables -A FORWARD -t mangle -p tcp --dport 443 -s 192.168.1.0/24 -j TTL --ttl-set 64

    iptables -A FORWARD -p tcp -s 192.168.1.0/24 -m state --state ESTABLISHED,RELATED -j ACCEPT
    iptables -A FORWARD -p tcp -d 192.168.1.0/24 -m state --state ESTABLISHED,RELATED -j ACCEPT

    # -------------------------------- Firewall <-> Internet ------------------------------ #

    # Permitir a Saida de consulta DNS
    iptables -A OUTPUT -p udp --dport 53 -d 8.8.8.8,8.8.4.4 -j ACCEPT
    iptables -A INPUT -p udp --sport 53 -s 8.8.8.8,8.8.4.4 --dport 1024:65535 -j ACCEPT
    
    # Permitindo a Saida de Ping
    iptables -A OUTPUT -p icmp --icmp-type echo-request -j ACCEPT
    iptables -A INPUT -p icmp --icmp-type echo-reply -j ACCEPT

    # Permitir a Saida para a Internet (HTTP/HTTPS)
    iptables -A OUTPUT -p tcp --syn -m multiport --dports 80,443 -j ACCEPT
    iptables -A INPUT -p tcp --syn -m multiport --sports 80,443 -j ACCEPT
      

    # ------------------------------ Internet <-> Firewall ------------------------------ #

    # Bloqueando Port Scan (SYN Scan, UDP Scan, TCP Scan, Xmas Scan, ACK Scan, Null Scan e FIN Scan)
    iptables -A INPUT -s -m recent --update --hitcount 5 --name INVASOR --seconds 3600 -j DROP
    iptables -A INPUT -s -p tcp --syn -m recent --set --name INVASOR
    iptables -A INPUT -s -p udp -m recent --set --name INVASOR 

    iptables -A INPUT -p tcp -m state --state ESTABLISHED,RELATED -j ACCEPT
    iptables -A OUTPUT -p tcp -m state --state ESTABLISHED,RELATED -j ACCEPT
    iptables -A INPUT -p udp -m state --state ESTABLISHED,RELATED -j ACCEPT
    iptables -A OUTPUT -p udp -m state --state ESTABLISHED,RELATED -j ACCEPT

    # Liberando Acesso a VPN
    iptables -A INPUT -p udp --dport 1194 -i eth1 -m state --state NEW -j ACCEPT
    iptables -A INPUT -i tun0 -j ACCEPT
    iptables -A OUTPUT -o tun0 -j ACCEPT

    # Permintindo o Acesso do Vagrant
    iptables -A INPUT -p tcp --dport 22 -i eth0 -m state --state NEW -j ACCEPT
    iptables -A INPUT -p tcp --dport 22 -i eth1 -m state --state NEW -j ACCEPT

    # Liberando DNAT para o Kali Linux
    iptables -A INPUT -p tcp --dport 2222 -i eth1 -d 192.168.100.133 -j ACCEPT
    iptables -A PREROUTING -t nat -i eth1 -p tcp --dport 2222 -j DNAT --to 192.168.1.33:22
    iptables -A FORWARD -p tcp --dport 22 -d 192.168.1.33 -j ACCEPT
    iptables -A FORWARD -p tcp --sport 22 -s 192.168.1.33 -j ACCEPT

    # -------------------------------- Rede Local <-> Firewall---------------------------- #

    # Bloqueando Port Scan (SYN Scan, UDP Scan, TCP Scan, Xmas Scan, ACK Scan, Null Scan e FIN Scan)
    iptables -A INPUT -s 192.168.1.0/24 -d 192.168.1.254 -m recent --update --hitcount 5 --name INVASOR --seconds 3600 -j DROP
    iptables -A INPUT -s 192.168.1.0/24 -d 192.168.1.254 -p tcp --syn -m recent --set --name INVASOR
    iptables -A INPUT -s 192.168.1.0/24 -d 192.168.1.254 -p udp -m recent --set --name INVASOR 


    # Habilitar o Acesso via SSH para o Firewall
    iptables -A INPUT -p tcp --dport 22 -i eth2 -d 192.168.1.254 -m state --state NEW -j ACCEPT

    # Priorizacao Maxima (TOS=10) para o SSH
    iptables -A INPUT -t mangle -p tcp --dport 22 -i eth2 -s 192.168.1.0/24 -j TOS --set-tos 16

    # Liberando Acesso ao DHCP
    iptables -A INPUT -p udp --dport 68 -d 192.168.1.254 -s 192.168.1.0/24 -j ACCEPT
    iptables -A OUTPUT -p udp --sport 67 -s 192.168.1.254 -d 192.168.1.0/24 -j ACCEPT
    
    # Bloqueando a máquina pelo endereço fisico (MAC)
    #iptables -I INPUT -p tcp --dport 22 -m mac --mac-source 08:00:27:5B:F1:F0 -j DROP

    # Bloquando um range de endereços IPs
    #iptables -I INPUT -p tcp --dport 22 -m iprange --src-range 192.168.1.30-192.168.1.40 -j DROP

    iptables -A INPUT -j DROP
    iptables -A OUTPUT -j DROP
}

stop () {
    iptables -F -t nat  
    iptables -F -t filter
    iptables -F -t mangle

    iptables -P INPUT 	ACCEPT
    iptables -P OUTPUT 	ACCEPT
    iptables -P FORWARD ACCEPT

    iptables -Z

}

restart () {
    stop
    start
}

case "$1" in 
    start)
        start
    ;;

    stop)
        stop
    ;;

    restart)
        restart
    ;;
esac
